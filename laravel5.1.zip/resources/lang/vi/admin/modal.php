<?php

return [
    'create' => 'Thêm mới',
    'edit' => 'Sửa',
    'reset' => 'Làm rỗng',
    'cancel' => 'Hủy bỏ',
    'general' => 'Trang chính',
    'title' => 'Tiêu đề',
    'new' => 'Thêm',
    'delete' => 'Xóa',
    'items' => 'Mục',
    'delete_message' => 'Bạn có muốn xóa mục này không?',
];
