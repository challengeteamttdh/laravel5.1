<?php

return [
    'category' => 'Danh mục',
    'subcategory' => 'Danh mục con',

];