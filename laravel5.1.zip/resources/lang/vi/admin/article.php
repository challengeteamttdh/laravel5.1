<?php

return [
    'article' => 'Bài viết',
    'introduction' => 'Giới thiệu',
    'content' => 'Nội dung',
    'source' => 'Nguồn',
    'picture' => 'Ảnh',
    'category' => 'Danh mục',

];