<?php

return [
    'code' => 'Code',
    'icon' => 'Icon',
    'languages' => 'Ngôn ngữ',

];