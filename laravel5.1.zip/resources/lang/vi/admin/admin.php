<?php

return [
	'settings' => 'Cài đặt',
	'homepage' => 'Xem trang chủ',
	'home' => 'Trang chủ',
	'welcome' => 'Xin chào',
    'action' => 'Thao tác',
    'back' => 'Trở về',
    'created_at' => 'Tạo lúc',
    'language' => 'Ngôn ngữ',
    'yes'       => 'Đồng ý',
    'no'        =>  'Hủy bỏ',
    'view_detail' => 'Xem chi tiết',
    'news_categories' => 'Danh mục bài viết',
    'news_items' => 'Article items',
    'photo_albums' => 'Photo albums',
    'photo_items' => 'Photo items',
    'users' => 'Tài khoản',
	];