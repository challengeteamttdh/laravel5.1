<?php

return [
    'photo' => 'Ảnh',
    'album' =>  'Album',
    'album_cover' => 'Album cover',
    'slider' => 'Slider',
    'description' => 'Description',
    'picture' => 'Picture',

];