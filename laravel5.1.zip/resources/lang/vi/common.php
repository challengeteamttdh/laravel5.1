<?php
/**
 * Created by PhpStorm.
 * User: thanhnd
 * Date: 28/02/2016
 * Time: 08:01
 */
return [
    'language' => 'Ngôn ngữ',
    'en' => 'Tiếng anh',
    'vi' => 'Tiếng việt',
];