<?php

return [
	'home' => 'Trang Chu',
	'login' => 'Dang Nhap',
	'sign_up' => 'Dang Ky',
	'admin_panel' => 'Trang Quan Tri',
	'logout' => 'Dang Xuat',
	'login_as' => 'Dang nhap nhu',
	

];
