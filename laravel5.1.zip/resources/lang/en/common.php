<?php
/**
 * Created by PhpStorm.
 * User: thanhnd
 * Date: 28/02/2016
 * Time: 08:01
 */
return [
    'language' => 'Language',
    'en' => 'English',
    'vi' => 'VietNam',
];