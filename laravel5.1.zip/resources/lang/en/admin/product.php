<?php

return [
    'category' => 'Category',
    'subcategory' => 'SubCategory',

];