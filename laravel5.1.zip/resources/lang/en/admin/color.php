<?php
/**
 * Created by PhpStorm.
 * User: thanhnd
 * Date: 28/02/2016
 * Time: 20:59
 */
return [
    'color' => 'Color',
    'name' => 'Name'
];