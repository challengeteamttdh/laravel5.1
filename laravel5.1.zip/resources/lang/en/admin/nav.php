<?php
/**
 * Created by PhpStorm.
 * User: thanhnd
 * Date: 28/02/2016
 * Time: 20:29
 */
return [
    'home' => 'Go to frontend',
    'dashboard' => 'Dashboard',
    'language' => 'Language',
    'pdm' => 'Product Management',
    'pdc' => 'Product Categories',
    'pd' => 'Product',
    'pdsc' => 'Product SubCategory',
    'color' => 'Color',
    'material' => 'Material',
    'producer' => 'Producer',
];